var mode = 0;
//Act 1 Variables
var r = -1;
var c;
var msg = "";
let song;
let song2;
let startX
let startY
let endX
let endY
//Act 2 Variables
let circleY = -20;
let circleX = 100;
let speedInitial = 2;
let score = 0;
let xRand;
let noise;
let music;
let colorPicker;
//Act 3 Variables
let patrickX = 250;
let patrickY = 250;
let jelly1X = 125;
let jelly2X = 250;
let jelly3X = 375;
let jellyY = 100;
let jelly1Y = 70;
let jelly2Y = 140;
let jelly3Y = 250;
let jellyX = 100;
let jspeed = 2;
let livesLeft = 3;
let surv = 0;

function setup() {
  createCanvas(500, 500);
  background('white')
  bgMusic.loop();
  bgMusic.stop();

}

function preload() {
  // preload() runs once
  bg = loadImage('mainmenu.jpg');
  bg1 = loadImage('mazebg.jpg');
  bg2 = loadImage('FallingObjectsbg.jpg');
  bg3 = loadImage('DodgingObjectsbg.jpg');
  //act 1 images and noises
  song = loadSound('buzzer.mp3')
  song2 = loadSound('cele.mp3')
  startX = 125
  startY = 45
  //act 2 images and noises
  spBob = loadImage('spongeBob.png');
  krPat = loadImage('krabbyPatty.png');
  noise = loadSound('correctDing.mp3');
  spBobEnd = loadImage('actTwoEndSponge.png');
  bgMusic = loadSound('SpongebobMusic.mp3');
  lostMusic = loadSound('SpongebobLost.mp3');

  //act 3 images
  pStar = loadImage('patrickstar.png');
  jFish = loadImage('jellyFish.webp');
  patS = loadImage('patrickstarend.webp');
  yikes = loadSound('yikes.mp3');
  lego = loadSound('lego.mp3')
  
  
}

function draw() {

  if (mode == 0) {
    clear();
    drawMenu();
    resetAct2();
    resetAct3();
  } else if (mode == 1) {
    
    Act1();
  } else if (mode == 2) {
    image(bg2, 0, 0);
    Act2();

    
  } else if (mode == 3) {
    image(bg3, 0, 0);
    fill('white');
    text("LIVES LEFT = " + livesLeft, 380, 485)
    text("ROUNDS SURVIVED = " + surv, 10, 485)
    fill('black')
    Act3();
  } 
  else if (mode == 4) {
    image(bg2, 0, 0);
    endScreenAct2();
    //ostMusic.play();   
  } else if (mode == 5) {
    endScreenAct3();
  } else if (mode == 6){
    instruction3();
  }
}

function drawMenu() {

  image(bg, 0, 0);
  textSize(30)
  strokeWeight(1)
  fill('black')
  text("Fine Motor Skills", 150, 50)

  textSize(15)
  fill('yellow')
  stroke('black')

  textSize(12)
  rect(130, 180, 70, 30, 10); //activity 2
  fill('black')
  noStroke()
  text("Catching \n Patties", 142, 192);

  fill('yellow')
  stroke('black')
  rect(320, 180, 70, 30, 10); //activity 3
  fill('black')
  noStroke()
  text("Dodging \nJellyfish", 333, 192);

  textSize(15)
  fill('yellow')
  stroke('black')
  rect(225, 80, 70, 30, 10); //activity 1
  fill('black')
  noStroke()
  text("Maze", 242, 100);

}
function mouseClicked() {
  if (mode == 0) {
    if (mouseX > 130 && mouseX < 200 && mouseY > 180 && mouseY < 210) {
      mode = 2
      bgMusic.play();
    } //this leads user to activity 2
    if (mouseX > 225 && mouseX < 295 && mouseY > 80 && mouseY < 110) {
      mode = 1
    }//leads user to activity 1
    if (mouseX > 320 && mouseX < 390 && mouseY > 180 && mouseY < 210) {
      //mode = 3
      mode = 6
    }//leads user to activity 3
  }
  if (mode == 1 || mode == 2 || mode == 3) {
    if (mouseX > 30 && mouseX < 60 && mouseY > 30 && mouseY < 60) {
      mode = 0
    } //checks if mouse is over back button
  }
  if (mode == 4) {
    mode = 0
  }
  if (mode == 5) {
    if (mouseX > 270 && mouseX < 350 && mouseY > 310 && mouseY < 350) {
      resetAct3();
      mode = 3;
    }//play again
    if (mouseX > 150 && mouseX < 230 && mouseY > 310 && mouseY < 350) {
      mode = 0
    }//exit
  }
  if (mode == 6) {
     if (mouseX > 128 && mouseX < 378 && mouseY > 290 && mouseY < 340) {
      mode = 3
  }
}
}

// function mousePressed() {
//   loop();
//   if (mode == 4) {
//     mode = 2
    
//   } 
// }

function Act1() { //maze

  background('yellow')

  textSize(15)
  fill('black')
  text("Instructions: Guide the mouse through the yellow part of the maze.\n Remember that you cannot go outside the white lines at any point!", width / 2-200 , height / 2 + 75);


  image(spBob, 100, 350, 200, 200);
  image(pStar, 300, 350, 150, 150)
  if (mouseX > 125 && mouseX < 150 && mouseY > 45 && mouseY < 70) {
    background('yellow');
    image(spBob, 100, 350, 200, 200);
    image(pStar, 300, 350, 150, 150)

  }
  backButton();
  noStroke()
  textSize(20)
  fill('lime')
  rect(125, 45, 25, 25)
  text("START", 125, 40)

  fill('red');
  rect(390, 90, 25, 20);
  text("END", 420, 110);

  fill("white");

  rect(150, 50, 25, 80);
  rect(175, 70, 120, 25);
  rect(150, 110, 70, 25);
  rect(250, 70, 25, 50);
  rect(230, 110, 115, 25);
  rect(290, 70, 100, 25);
  rect(322, 85, 25, 90);
  rect(110, 150, 200, 25);
  rect(110, 70, 25, 130);
  rect(110, 190, 80, 25);
  rect(75, 70, 50, 25);
  rect(70, 70, 25, 180);
  rect(70, 230, 200, 25);
  rect(200, 190, 25, 65);
  rect(200, 190, 185, 25);
  rect(360, 110, 25, 145);
  rect(280, 230, 100, 25);
  rect(360, 110, 50, 25);

  
    
    
  
    if (mouseX > 125 && mouseX < 150 && mouseY > 45 && mouseY < 70) {
      r = 1;
      msg = "";
    }
    if (r == 1) {
      strokeWeight(2)
      stroke('purple')
    }
    if (r == 1 && mouseX > 390 && mouseX < 415 && mouseY > 90 && mouseY < 110) {
      msg = "You win!";
      c = "orange";
      song2.play()
      
    }
    if (r == -1) {
      msg = "Begin!";
      c = "orange"
    }
    textSize(50);
    fill(c);
    text(msg, width / 2 - 100, height / 2 - 100);
  
    if(mouseY<50 || mouseY>230){
       r = 0;
      msg = "  Start\n  Again"
      c = "red";
      song.play()
    }
  
    if (mouseX > 150 && mouseX < 175 && mouseY > 50 && mouseY < 130) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red";
      song.play()
    }
    if (mouseX > 175 && mouseX < 295 && mouseY > 70 && mouseY < 95) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 150 && mouseX < 220 && mouseY > 110 && mouseY < 135) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 250 && mouseX < 275 && mouseY > 70 && mouseY < 120) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 230 && mouseX < 345 && mouseY > 110 && mouseY < 135) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 290 && mouseX < 390 && mouseY > 70 && mouseY < 95) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 322 && mouseX < 347 && mouseY > 85 && mouseY < 175) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 110 && mouseX < 310 && mouseY > 150 && mouseY < 175) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 110 && mouseX < 135 && mouseY > 70 && mouseY < 100) {
      ready = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 220 && mouseX < 460 && mouseY > 360 && mouseY < 460) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 110 && mouseX < 190 && mouseY > 190 && mouseY < 215) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 75 && mouseX < 125 && mouseY > 70 && mouseY < 95) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 70 && mouseX < 95 && mouseY > 70 && mouseY < 250) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 70 && mouseX < 270 && mouseY > 230 && mouseY < 255) {
      r = 0;
      msg = "  Start\n  Again";
      c = "red";
      song.play()
    }
    if (mouseX > 200 && mouseX < 225 && mouseY > 190 && mouseY < 255) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 200 && mouseX < 385 && mouseY > 190 && mouseY < 215) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 360 && mouseX < 385 && mouseY > 110 && mouseY < 255) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 280 && mouseX < 380 && mouseY > 230 && mouseY < 255) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
    if (mouseX > 360 && mouseX < 410 && mouseY > 110 && mouseY < 135) {
      r = 0;
      msg = "  Start\n  Again"
      c = "red"
      song.play()
    }
  }//maze

function Act2() { //falling objects
  colorPicker = createColorPicker('yellow');
  colorPicker.position(-200, 200);
  backButton()

  fill('black')
  text("Use the mouse to control Spongebob and eat the Krabby Patty",75,55)

  //find distance between circle to know when user catches object
  let distX = circleX + 15 - mouseX;
  let distY = circleY + 15 - height - 40;
  let distance = sqrt((distX * distX) + (distY * distY));

  fill('white')    
  textSize(20)
  text("Score = " + score, 10, 90)

  //makes spongebob moving with mouse
  fill(colorPicker.color());
  circle(mouseX, height - 40, 80);
  image(spBob, mouseX - 30, height - 70, 70, 70);

  //falling krabby patty
  fill(colorPicker.color());
  circle(circleX + 15, circleY + 15, 35);
  image(krPat, circleX, circleY, 30, 30);

  //increases speed over time, increasing difficulty
  circleY += speed;

  if (distance < 50) {
    noise.play();
    circleY = -20
    speed += 1
    score += 1
  }

  if (circleY > height) {
    bgMusic.stop();       
    //lostMusic.play();   
    mode = 4;
    
    act2LostMusic();
  }
  if (circleY == -20) {
    circleX = random(40, width - 20);
    
    //circleY += speed;
  }

}//falling objects
function act2BgMusic(){
  noLoop();
  bgMusic.play();
}

function act2LostMusic() {
 
  if(mode==4){
  lostMusic.play();   
 }
 
  
}
function endScreenAct2() {  
  fill('orange')
  rect(125, 115, 250, 255, 20)
  image(spBobEnd,170,128,150,150);
  
  fill(245, 215, 66)
  textSize(20)
  rect(180, 310, 137, 40, 30)
  //rect(270, 310, 80, 40, 5)
  //fill('red')
  fill('red')
  textSize(50)

  fill('orange')
  text("GAME OVER", (width / 2) -150,100)
  fill('black')
  textSize(20)
  text("Score = " + score, (width / 2) - 47, height / 2 + 46)
  //text("Dev High Score = 43", (width / 2) - 70, height / 2 + 60)
  text("Main Menu", (width / 2) - 50, height / 2 + 85);
  //nofill()
  //lostMusic.play();   
}

function resetAct2() {
  score = 0;
  speed = 2;
  circleY = -20;
}

function Act3() { //dodging game

  backButton();
  collision();

  image(pStar, patrickX, patrickY, 70, 70);

  image(jFish, jelly1X, jellyY, 30, 30);
  image(jFish, jelly2X, jellyY, 30, 30);
  image(jFish, jelly3X, jellyY, 30, 30);
  image(jFish, jellyX, jelly1Y, 30, 30);
  image(jFish, jellyX, jelly2Y, 30, 30);
  image(jFish, jellyX, jelly3Y, 30, 30);

  jellyY += jspeed;
  jellyX += jspeed;

  if (jellyY >= height) {
    jellyY = 0;
    jelly1X, jelly2X, jelly3X = random(width);
    lego.play();
    surv += 1;
  }
  if (jellyX >= width) {
    jellyX = 0;
    jelly1Y, jelly2Y, jelly3Y = random(height);
  }

  if (livesLeft <= 0) {
    mode = 5
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    patrickX -= 20;
    if (patrickX < -15) {
        patrickX += 20
      }
  }
  if (keyCode === RIGHT_ARROW) {
    patrickX += 20;
    if (patrickX > 460) {
        patrickX -=  20
      }
  }
  if (keyCode === UP_ARROW) {
    patrickY -= 20
      if (patrickY < -10) {
        patrickY += 20
        }
  }
  if (keyCode === DOWN_ARROW) {
    patrickY += 20;
    if (patrickY > 445) {
        patrickY -= 20
      }
  }
}

function collision() {
  if (patrickX + 70 >= jelly1X + 30 && patrickX <= jelly1X + 30 && patrickY >= jellyY && patrickY <= jellyY) {
    yikes.play()
    livesLeft -= 1;
  }
  if (patrickX + 70 >= jelly2X + 30 && patrickX <= jelly2X + 30 && patrickY >= jellyY && patrickY <= jellyY) {
    yikes.play()
    livesLeft -= 1;
  }
  if (patrickX + 70 >= jelly3X + 30 && patrickX <= jelly3X + 30 && patrickY >= jellyY && patrickY <= jellyY) {
    yikes.play()
    livesLeft -= 1;
  }
  if (patrickY + 70 >= jelly1Y + 30 && patrickY <= jelly1Y + 30 && patrickX >= jellyX && patrickX <= jellyX) {
    yikes.play()
    livesLeft -= 1;
  }
  if (patrickY + 70 >= jelly2Y + 30 && patrickY <= jelly2Y + 30 && patrickX >= jellyX && patrickX <= jellyX) {
    yikes.play()
    livesLeft -= 1;
  }
  if (patrickY + 70 >= jelly3Y + 30 && patrickY <= jelly3Y + 30 && patrickX >= jellyX && patrickX <= jellyX) {
    yikes.play()
    livesLeft -= 1;
  }
}

function endScreenAct3() {
  background(184, 226, 242)
  stroke(255, 255, 255)
  strokeWeight(1)
  fill(255, 192, 203)
  rect(125, 125, 250, 250, 20)
  fill(252, 238, 167)
  rect(150, 310, 80, 40, 5)
  rect(270, 310, 80, 40, 5)
  strokeWeight(0)
  image(patS, 205, 180, 90, 90)
  textSize(20)
  fill('green')
  text("GOOD JOB!", 195, 160)
  textSize(12)
  text("ROUNDS SURVIVED = " + surv, 185, 295)
  fill('black')
  text("EXIT", 176, 335);
  text(" PLAY\nAGAIN", 290, 329)
}

function resetAct3() {
  livesLeft = 3;
  surv = 0
  jellyY = 0
  jellyX = 0
}

function instruction3() {
  background(184, 226, 242)
  stroke(255, 255, 255)
  strokeWeight(1)
  fill(255, 192, 203)
  rect(75, 125, 350, 250, 20)
  noStroke()
  textSize(25)
  fill('white')
  text("INSTRUCTIONS", 160, 160)
  textSize(18)
  text("use the arrows on the keyboard to move \n  Patrick and avoid touching the jellyfish", 90, 220)
  //fill(252, 238, 167)
  stroke(231, 84, 128)
  strokeWeight(2)
  rect(128, 290, 250, 50, 10)
  noStroke()
  fill(90, 90, 90)
  textSize(23)
  text("Start Game!", 190, 325)
}

function backButton() {
  fill(0, 0, 128)
  rect(30, 30, 40, 40, 20)
  fill('white')
  textSize(10)
  text("Home", 37, 53)
  textSize(15)
}
